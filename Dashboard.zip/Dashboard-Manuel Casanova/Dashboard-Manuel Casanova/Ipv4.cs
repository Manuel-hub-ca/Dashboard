﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.IO;

namespace Dashboard_Manuel_Casanova
{
    public partial class Ipv4 : Form
    {
        public Ipv4()
        {
            InitializeComponent();
        }

        string dirPath = @".\IPv4\";
        string filePath = @".\IPv4\Ipv4.text";

        private void Ipv4_Load(object sender, EventArgs e)
        {

            DateTime dateTime = DateTime.Now;
            label1.Text += " " + dateTime.ToShortDateString();
            if (!Directory.Exists(dirPath))
            {
                Directory.CreateDirectory(dirPath);
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to exit the IPv4 App?", "Exit?", MessageBoxButtons.YesNo) == DialogResult.Yes) { this.Close(); }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            Regex r1 = new Regex(@"^(25[0-5]|2[0-4]\d|[0-1]?\d?\d)(\.(25[0-5]|2[0-4]\d|[0-1]?\d?\d)){3}$");
            if (r1.IsMatch(textBox1.Text.Trim()) == true)
            {
                MessageBox.Show(textBox1.Text + "\n" + "The IP address is correct");
            }
            else
            {
                MessageBox.Show(textBox1.Text + "\n" + "The IP must have 4 bytes\n" + "integer numbers between 0 and 255\n " +
                    "separated by a dot (255.255.255.255)", "Error");
            }
            
            
          FileStream fs = null;
            
            try
            {
                fs = new FileStream(filePath, FileMode.Append, FileAccess.Write);
                if (textBox1.Text != "")
                {
                    BinaryWriter textOut = new BinaryWriter(fs);
                    textOut.Write(textBox1.Text + "   " + DateTime.Now.ToString() + "\n");
                    textOut.Close();
                }
            }
            catch (IOException ex){ MessageBox.Show(ex.Message, "IOException"); }
            finally{
                if (fs != null){fs.Close();}
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            
        }
    }
}
