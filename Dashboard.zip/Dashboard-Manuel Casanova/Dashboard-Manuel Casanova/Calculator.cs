﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Dashboard_Manuel_Casanova
{
    public partial class Calculator : Form
    {
        public Calculator()
        {
            InitializeComponent();
        }
        string dirPath = @".\Calculator\";
        string filePath = @".\Calculator\Calculator.text";
        int display_number;
        decimal num1 = 0;
        decimal num2 = 0;
        decimal res = 0;
        int counter = 0;
       
        string op_ = "";
        private void Calculator_Load(object sender, EventArgs e)
        {
            display_number = 0;
            textBox1.Text = display_number.ToString();
            if (!Directory.Exists(dirPath)) {
                Directory.CreateDirectory(dirPath);
            }
            
            
        }

        private void button18_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Do you want to exit the Simple Calculator", "Exit?", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void button17_Click(object sender, EventArgs e)
        { 
            textBox1.Clear();
            textBox1.Text = display_number.ToString();
            op_ = "";
            num2 = 0;

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (textBox1.Text == "0")
            {

                textBox1.Clear();

            }
            else if (counter == 0 && num2 == 0 && op_ == "+" || counter == 0 && num2 == 0 && op_ == "-" || counter == 0 && num2 == 0 && op_ == "*" || counter == 0 && num2 == 0 && op_ == "/")
            { textBox1.Clear();
                
            }
           
            
           
            if(op_ == "") {
                textBox1.Text += "1";
                num1 = Convert.ToDecimal(textBox1.Text);
            }
            else if (op_ == "+" || op_ == "-" || op_ == "*" || op_ == "/")
            {
                
                textBox1.Text += "1";
                num2 = Convert.ToDecimal(textBox1.Text);
               
            }

            if (counter > 0)
            {
                counter--;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {

                textBox1.Clear();

            }
            else if (counter == 0 && num2 == 0 && op_ == "+" || counter == 0 && num2 == 0 && op_ == "-" || counter == 0 && num2 == 0 && op_ == "*" || counter == 0 && num2 == 0 && op_ == "/") 
            { textBox1.Clear();
                
            }


            if (op_ == "")
            {
                textBox1.Text += "2";
                num1 = Convert.ToDecimal(textBox1.Text);
            }
            else if (op_ == "+" || op_ == "-" || op_ == "*" || op_ == "/")
            {
                
                textBox1.Text += "2";
                num2 = Convert.ToDecimal(textBox1.Text); 
            }

            if (counter > 0)
            {
                counter--;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            if (textBox1.Text == "0")
            {

                textBox1.Clear();

            }
            else if (counter == 0 && num2 == 0 && op_ == "+" || counter == 0 && num2 == 0 && op_ == "-" || counter == 0 && num2 == 0 && op_ == "*" || counter == 0 && num2 == 0 && op_ == "/") 
            { textBox1.Clear(); }


            if (op_ == "")
            {
                textBox1.Text += "3";
                num1 = Convert.ToDecimal(textBox1.Text);
            }
            else if (op_ == "+" || op_ == "-" || op_ == "*" || op_ == "/")
            {
                
                textBox1.Text += "3";
                num2 = Convert.ToDecimal(textBox1.Text);

            }

            if (counter > 0)
            {
                counter--;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {


            if (textBox1.Text == "0")
            {

                textBox1.Clear();

            }
            else if (counter == 0 && num2 == 0 && op_ == "+" || counter == 0 && num2 == 0 && op_ == "-" || counter == 0 && num2 == 0 && op_ == "*" || counter == 0 && num2 == 0 && op_ == "/") 
            { textBox1.Clear(); }

            if (op_ == "")
            {
                textBox1.Text += "4";
                num1 = Convert.ToDecimal(textBox1.Text);
            }
            else if (op_ == "+" || op_ == "-" || op_ == "*" || op_ == "/")
            {
               
                textBox1.Text += "4";
                num2 = Convert.ToDecimal(textBox1.Text);

            }

            if (counter > 0)
            {
                counter--;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {

            if (textBox1.Text == "0")
            {

                textBox1.Clear();

            }
            else if (counter == 0 && num2 == 0 && op_ == "+" || counter == 0 && num2 == 0 && op_ == "-" || counter == 0 && num2 == 0 && op_ == "*" || counter == 0 && num2 == 0 && op_ == "/") 
            { textBox1.Clear(); }


            if (op_ == "")
            {
                textBox1.Text += "5";
                num1 = Convert.ToDecimal(textBox1.Text);
            }
            else if (op_ == "+" || op_ == "-" || op_ == "*" || op_ == "/")
            {
                
                textBox1.Text += "5";
                num2 = Convert.ToDecimal(textBox1.Text);

            }

            if (counter > 0)
            {
                counter--;
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {

            if (textBox1.Text == "0")
            {

                textBox1.Clear();

            }
            else if (counter == 0 && num2 == 0 && op_ == "+" || counter == 0 && num2 == 0 && op_ == "-" || counter == 0 && num2 == 0 && op_ == "*" || counter == 0 && num2 == 0 && op_ == "/") 
            { textBox1.Clear(); }


            if (op_ == "")
            {
                textBox1.Text += "6";
                num1 = Convert.ToDecimal(textBox1.Text);
            }
            else if (op_ == "+" || op_ == "-" || op_ == "*" || op_ == "/")
            {
                
                textBox1.Text += "6";
                num2 = Convert.ToDecimal(textBox1.Text);

            }

            if (counter > 0)
            {
                counter--;
            }

        }

        private void button7_Click(object sender, EventArgs e)
        {

            if (textBox1.Text == "0")
            {

                textBox1.Clear();

            }
            else if (counter == 0 && num2 == 0 && op_ == "+" || counter == 0 && num2 == 0 && op_ == "-" || counter == 0 && num2 == 0 && op_ == "*" || counter == 0 && num2 == 0 && op_ == "/") 
            { textBox1.Clear(); }


            if (op_ == "")
            {
                textBox1.Text += "7";
                num1 = Convert.ToDecimal(textBox1.Text);
            }
            else if (op_ == "+" || op_ == "-" || op_ == "*" || op_ == "/")
            {
                
                textBox1.Text += "7";
                num2 = Convert.ToDecimal(textBox1.Text);

            }

            if (counter > 0)
            {
                counter--;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {

            if (textBox1.Text == "0")
            {

                textBox1.Clear();

            }
            else if (counter == 0 && num2 == 0 && op_ == "+" || counter == 0 && num2 == 0 && op_ == "-" || counter == 0 && num2 == 0 && op_ == "*" || counter == 0 && num2 == 0 && op_ == "/")
            { textBox1.Clear(); }


            if (op_ == "")
            {
                textBox1.Text += "8";
                num1 = Convert.ToDecimal(textBox1.Text);
            }
            else if (op_ == "+" || op_ == "-" || op_ == "*" || op_ == "/")
            {
                
                textBox1.Text += "8";
                num2 = Convert.ToDecimal(textBox1.Text);

            }

            if (counter > 0)
            {
                counter--;
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {

                textBox1.Clear();

            }
            else if (counter == 0 && num2 == 0 && op_ == "+" || counter == 0 && num2 == 0 && op_ == "-" || counter == 0 && num2 == 0 && op_ == "*" || counter == 0 && num2 == 0 && op_ == "/")
            { textBox1.Clear(); }



            if (op_ == "")
            {
                textBox1.Text += "9";
                num1 = Convert.ToDecimal(textBox1.Text);
            }
            else if (op_ == "+" || op_ == "-" || op_ == "*" || op_ == "/")
            {
                
                textBox1.Text += "9";
                num2 = Convert.ToDecimal(textBox1.Text);

            }

            if (counter > 0)
            {
                counter--;
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {

            if (textBox1.Text == "0")
            {

                textBox1.Clear();

            }
            else if (counter == 0 && num2 == 0 && op_ == "+" || counter == 0 && num2 == 0 && op_ == "-" || counter == 0 && num2 == 0 && op_ == "*" || counter == 0 && num2 == 0 && op_ == "/")
            { textBox1.Clear(); }


            if (op_ == "")
            {
                textBox1.Text += "0";
                num1 = Convert.ToDecimal(textBox1.Text);
            }
            else if (op_ == "+" || op_ == "-" || op_ == "*" || op_ == "/")
            {

                textBox1.Text += "0";
                num2 = Convert.ToDecimal(textBox1.Text);
                counter++;

            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            textBox1.Text += ".";
        }



        private void button12_Click(object sender, EventArgs e)
        {
            op_ = button12.Text;
           
        }

        private void button13_Click(object sender, EventArgs e)
        {
            op_ = button13.Text;
         
        }

        private void button14_Click(object sender, EventArgs e)
        {
            op_ = button14.Text;
            
        }

        private void button15_Click(object sender, EventArgs e)
        {
            op_ = button15.Text;
           
        }

        private void button16_Click(object sender, EventArgs e)
        {
            switch (op_)
            {
                case "+": res = num1 + num2;
                    textBox1.Text = res.ToString();
            break;
                case "-": res = num1 - num2;
                    textBox1.Text = res.ToString();
                    break;

                case "*": res = num1 * num2;
                          textBox1.Text = res.ToString();
                    break;

                case "/": res = num1 / num2;
                          textBox1.Text = res.ToString();
                    break;

            }

            FileStream fs = null;
                
            try
            {
                fs = new FileStream(filePath, FileMode.Append, FileAccess.Write);
                StreamWriter textOut = new StreamWriter(fs);
                textOut.WriteLine(num1 + op_ + num2 + "=" + res);
                textOut.Close();
                
            }
            catch (IOException exp) { MessageBox.Show(exp.Message, "IOException"); }

            finally { if (fs != null) { fs.Close(); } }
           
        }

      
    }
}
