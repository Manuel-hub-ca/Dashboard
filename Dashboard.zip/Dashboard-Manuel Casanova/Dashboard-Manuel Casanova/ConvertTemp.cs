﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Dashboard_Manuel_Casanova
{
    public partial class ConvertTemp : Form
    {
        public ConvertTemp()
        {
            InitializeComponent();
        }

        string dirPath = @".\Converted_Temp\";
        string filePath = @".\Converted_Temp\TempConversions.txt";

        private void ConvertTemp_Load(object sender, EventArgs e)
        {
            if (!Directory.Exists(dirPath)) {
                Directory.CreateDirectory(dirPath);
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                label2.Text = "C";
                label3.Text = "F";
            }

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                label2.Text = "F";
                label3.Text = "C";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to quit this App Temerature Conversion?", "Exit", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            float temp = 0, res = 0;
            string msg_textBox3 = "";
            string new_line = Environment.NewLine;

            try
            {
                temp = float.Parse(textBox1.Text);
                if (radioButton1.Checked)
                {
                    res = (temp * 9 / 5) + 32;
                }
                else
                {

                    res = (temp - 32) * 5 / 9;


                }

                if (res == 100 || res == 212)
                {
                    msg_textBox3 = "Water boils";
                }
                else if (res == 40 || res == 104)
                {
                    msg_textBox3 = "Hot Bath";
                }
                else if (res == 37 || res == (float)98.6)
                {
                    msg_textBox3 = "Body temperature";
                }
                else if (res == 30 || res == 86)
                {
                    msg_textBox3 = "Beach weather";
                }
                else if ((temp == 21 || res == 70) || (temp == 70 || res == 21))
                {
                    msg_textBox3 = "Room Temperature";
                }
                else if (res == 10 || res == 50)
                {
                    msg_textBox3 = "Cool Day";
                }
                else if (res == 0 || res == 32)
                {
                    msg_textBox3 = "Freezing point of water";
                }
                else if ((temp == -18 || res == 0) || (temp == 0 || res == -18))
                {
                    msg_textBox3 = "Very Cold Day";
                }
                else if (res == -40)
                {
                    msg_textBox3 = "Extremely Cold Day" + new_line + "(" + res + ")";
                }


                //if (Convert.ToDouble(textBox1.Text) < 12) {
                //        textBox1.ForeColor = Color.Blue;
                //        textBox2.ForeColor = Color.Blue;
                //}


                if (radioButton1.Checked && temp <= 0)
                {   
                    
                    textBox1.ForeColor = Color.Blue;
                    textBox2.BackColor = Color.White;
                    textBox2.ForeColor = Color.Blue;
                   
                    
                }

                else if (radioButton1.Checked && temp >= 30)
                {
                    textBox1.ForeColor = Color.Red;
                    textBox2.BackColor = Color.White;
                    textBox2.ForeColor = Color.Red;
                }

                else if (radioButton1.Checked && temp >= 10 || temp <= 23) {
                    textBox1.ForeColor = Color.Green;
                    textBox2.BackColor = Color.White;
                    textBox2.ForeColor = Color.Green;
                }

                if (radioButton2.Checked && temp <= 0)
                {

                    textBox1.ForeColor = Color.Blue;
                    textBox2.BackColor = Color.White;
                    textBox2.ForeColor = Color.Blue;


                }

                else if (radioButton2.Checked && temp >= 86)
                {
                    textBox1.ForeColor = Color.Red;
                    textBox2.BackColor = Color.White;
                    textBox2.ForeColor = Color.Red;
                }

                else if (radioButton2.Checked && temp >= 50 && temp <= 73)
                {
                    textBox1.ForeColor = Color.Green;
                    textBox2.BackColor = Color.White;
                    textBox2.ForeColor = Color.Green;
                }




            }

            catch (Exception exp) { MessageBox.Show(exp.Message); }

            finally
            {

                textBox2.Text = res.ToString("0.#");
                textBox3.Text = msg_textBox3;
            }

            FileStream fs = null;
            string word1 = label2.Text;
            string word2 = label3.Text;
            


            try
            {
                fs = new FileStream(filePath, FileMode.Append, FileAccess.Write);
                StreamWriter textIn = new StreamWriter(fs);
                textIn.WriteLine((temp + " " + word1 + "=" + res + " " + word2 + "," + "   " + DateTime.Now.ToShortDateString() + "  " + DateTime.Now.ToLongTimeString() + "  " + msg_textBox3));
                textIn.Close();
            }
            catch (IOException ex) {
                MessageBox.Show(ex.Message, "IOException");
            }

            finally {
                if (fs != null) { fs.Close(); }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FileStream fs = null;
            string row = "";

            try {
                fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                StreamReader textOut = new StreamReader(fs);

                while( textOut.Peek() != -1)
                {
                    row += textOut.ReadLine() + "\n";
                }
                MessageBox.Show(row, " Converted temperature - Manuel");
                textOut.Close();

            }
            catch (FileNotFoundException) { MessageBox.Show(filePath + "not found!", "File not found"); }
            finally { if(fs != null) {fs.Close();}
            }
        }   
    }
}
