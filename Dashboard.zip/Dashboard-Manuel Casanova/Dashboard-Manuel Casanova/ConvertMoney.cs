﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Dashboard_Manuel_Casanova
{
    public partial class ConvertMoney : Form
    {
        //2022-07-18

        ////1 CAD------->USD:0.77
        ////             EUR:0.76
        ////             GBP:0.64
        ////             CUB:18.58

        ////1 USD------->CAD:1.30
        ////             EUR:0.98
        ////             GBP:0.83
        ////             CUB:24.06

        ////1 GBP------->USD:1.20
        ////             EUR:1.17
        ////             CAD:1.56
        ////             CUB:28.89

        ////1 EUR------->USD:1.02
        ////             CAD:1.32:
        ////             GBP:0.85
        ////             CUB:24.62

        ////1 CUB------->USD:0.042
        ////             EUR:0.041
        ////             GBP:0.035
        ////             CAD:0.054
       
        
        public ConvertMoney()
        {
            InitializeComponent();
        }

        string dirPath = @".\Converted_Money\";
        string filePath = @".\Converted_Money\data.text";

        private void ConvertMoney_Load(object sender, EventArgs e)
        {
            if (!Directory.Exists(dirPath))
            {
                Directory.CreateDirectory(dirPath);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Do you want to quit the application MoneyExchage?", "Exit?", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double money;
            double res = 0;
            bool[] options = {  cad1.Checked && usd2.Checked, cad1.Checked && eur2.Checked, cad1.Checked && gbp2.Checked, cad1.Checked && cub2.Checked,
                usd1.Checked && cad2.Checked, usd1.Checked && eur2.Checked, usd1.Checked && gbp2.Checked, usd1.Checked && cub2.Checked,
                gbp1.Checked && cad2.Checked, gbp1.Checked && usd2.Checked, gbp1.Checked && eur2.Checked, gbp1.Checked && cub2.Checked,
                eur1.Checked && cad2.Checked, eur1.Checked && usd2.Checked, eur1.Checked && gbp2.Checked, eur1.Checked && cub2.Checked,
                cub1.Checked && cad2.Checked, cub1.Checked && usd2.Checked, cub1.Checked && eur2.Checked, cub1.Checked && gbp2.Checked};
                
            double[] exrate = new double[] { 0.77, 0.76, 0.64, 18.58,
                                            1.30, 0.98, 0.83, 24.06, 
                                            1.20, 1.17, 1.56, 28.89, 
                                            1.02, 1.32, 0.85, 24.62,
                                            0.042, 0.041, 0.035, 0.054 };
            
            try
            {
                money = Convert.ToDouble(TextBox1.Text);
                
                for(int i=0; i<exrate.Length; i++) {

                    if (options[i]==true) {
                        res = money * exrate[i];
                    }

                    else if (cad1.Checked && cad2.Checked || usd1.Checked && usd2.Checked || eur1.Checked && eur2.Checked || gbp1.Checked && gbp1.Checked || cub1.Checked && cub2.Checked)
                    {
                        res = money;
                    }
                }
            }

            catch (Exception exp) {
                MessageBox.Show(exp.Message);
            }
            
            finally {TextBox2.Text = res.ToString(); }

            FileStream fs = null;
            string word1 = "";
            string word2 = "";

            try {
                fs = new FileStream(filePath, FileMode.Append, FileAccess.Write);
                StreamWriter textIn = new StreamWriter(fs);


                if (cad1.Checked) {
                    word1 = cad1.Text;
                }

                else if (usd1.Checked) {
                    word1 = usd1.Text;
                }

                else if (eur1.Checked) {
                    word1 = eur1.Text;
                }

                else if (gbp1.Checked) {
                    word1 = gbp1.Text;
                }

                else if (cub1.Checked) {
                    word1 = cub1.Text;
                }

                
                if (cad2.Checked)
                {
                    word2 = cad2.Text;
                }

                else if (usd2.Checked)
                {
                    word2 = usd2.Text;
                }

                else if (eur2.Checked)
                {
                    word2 = eur2.Text;
                }

                else if (gbp2.Checked)
                {
                    word2 = gbp2.Text;
                }

                else if (cub2.Checked)
                {
                    word2 = cub2.Text;
                }


                textIn.WriteLine(TextBox1.Text + " " + word1 + " " + "=" + " " + TextBox2.Text + " " + word2 + ",  " + DateTime.Now.ToShortDateString() + "  " + DateTime.Now.ToLongTimeString());
                textIn.Close();
            }

            catch (IOException ex) {
                MessageBox.Show(ex.Message, "IOException");

            }

            finally {
                if (fs != null)
                {
                    fs.Close();
                }
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {

            FileStream fs = null;
            string row = "";
            try
            {
                fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                StreamReader textOut = new StreamReader(fs);

                while (textOut.Peek() != -1)
                {
                    row += textOut.ReadLine() + "\n";
                }
                MessageBox.Show(row, "Data of Money Converted");
                textOut.Close();

            }

            catch(FileNotFoundException){
                MessageBox.Show(filePath + " " + "not found!", "File not found");
            }
        }
    }
}
