﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Dashboard_Manuel_Casanova
{

    public partial class frmMax : Form
    {
        public frmMax()
        {
            InitializeComponent();
        }

        string dirPath = @".\Lotto\";
        string filePath = @".\Lotto\LottoNbrs.text";

        private void button1_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Do you want to quit this application", "Exit?", MessageBoxButtons.YesNo)== DialogResult.Yes)this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int[] displayNbrs = new int[8];
            Random random = new Random();
            int randomNumber;
            randomNumber = random.Next(1, 50);
            displayNbrs[0] = randomNumber;

            for (int i = 1; i < 9;)
            {
                for (int j = 0; j < i; j++)
                {
                    if (randomNumber != displayNbrs[j])
                    {
                        displayNbrs[i - 1] = randomNumber;
                    }
                    else
                    {
                        randomNumber = random.Next(1, 50);
                    }
                }
                i++;
            }

            string numbers = "";
            string newLine = Environment.NewLine;
            foreach (int elm in displayNbrs)
            {
                numbers += elm.ToString() + newLine;
            }
            textBox1.Text = numbers;



            FileStream fs = null;
            string number2 = "";
            int seventh_num = 0;
            int extra = 0;



            try
            {

                fs = new FileStream(filePath, FileMode.Append, FileAccess.Write);
                for (int i = 0; i < 8; i++)
                {
                    if (i < 6) { number2 += displayNbrs[i] + ","; }
                    else if (i == 6) { seventh_num = displayNbrs[6]; }
                    else { extra = displayNbrs[7]; }
                }

                if (textBox1.Text != "")
                {
                    StreamWriter textOut = new StreamWriter(fs);
                    textOut.WriteLine("Max," + DateTime.Now.ToShortDateString() + "   " + DateTime.Now.ToLongTimeString() + ", " + number2 + seventh_num + "  " + "Extra:" + extra);
                    textOut.Close();
                }
            }

            catch (IOException ex)
            {
                MessageBox.Show(ex.Message, "IOException");
            }

            finally
            {
                if (fs != null) { fs.Close(); }
            }


        }

        private void button3_Click(object sender, EventArgs e)
        {
            //string dirPath = @".\Files\";
            //string filePath = @".\Files\LottoNbrs.text";
            //string row = "";
            FileStream fs = null;

            try
            {
                fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                //StreamReader sr = new StreamReader(filePath);

                //while (sr.Peek() != -1)
                //{
                //    row += sr.ReadLine() + "\n";
                //}
                
                //MessageBox.Show(row, "Lotto Max Manuel");
                //sr.Close();


                if (File.Exists(filePath))
                {
                    MessageBox.Show(File.ReadAllText(filePath));
                    //sr.Close();
                }
            }

            catch (FileNotFoundException)
            {
                MessageBox.Show(filePath + " " + "not found.", "File not found!");
            }


            finally
            {

                if (fs != null)
                {
                    fs.Close();
                }

            }

        }

        private void frmMax_Load(object sender, EventArgs e)
        {
            if (!Directory.Exists(dirPath))
            {
                Directory.CreateDirectory(dirPath);
            }

        }
    }
}
